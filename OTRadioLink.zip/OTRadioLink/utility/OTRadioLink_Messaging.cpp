/*
 * OTRadioLink_Messaging.cpp
 *
 *  Created on: 18 May 2017
 *      Author: denzo
 */

#include "OTRadioLink_Messaging.h"

#ifdef ARDUINO
#include <Arduino.h>
#endif

namespace OTRadioLink {

}
