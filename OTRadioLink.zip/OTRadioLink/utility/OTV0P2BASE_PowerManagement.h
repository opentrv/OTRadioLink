/*
The OpenTRV project licenses this file to you
under the Apache Licence, Version 2.0 (the "Licence");
you may not use this file except in compliance
with the Licence. You may obtain a copy of the Licence at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the Licence is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied. See the Licence for the
specific language governing permissions and limitations
under the Licence.

Author(s) / Copyright (s): Damon Hart-Davis 2013--2015
                           Deniz Erbilgin 2015
*/

/*
  Utilities to assist with minimal power usage on V0p2 boards,
  including interrupts and sleep.
  */

#ifndef OTV0P2BASE_POWERMANAGEMENT_H
#define OTV0P2BASE_POWERMANAGEMENT_H

#include <stdint.h>
#include <util/atomic.h>
#include <Arduino.h>

#include "OTV0P2BASE_BasicPinAssignments.h"
#include "OTV0P2BASE_FastDigitalIO.h"

namespace OTV0P2BASE
{


// If true, default is to run the SPI bus a bit below maximum (eg for REV2 board).
static const bool DEFAULT_RUN_SPI_SLOW = false;

// TEMPLATED DEFINITIONS OF SPI power up/down.
//
// If SPI was disabled, power it up, enable it as master and with a sensible clock speed, etc, and return true.
// If already powered up then do nothing other than return false.
// If this returns true then a matching powerDownSPI() may be advisable.
// The optional slowSPI flag, if true, attempts to run the bus slow, eg for when long or loaded with LED on SCK.
template <uint8_t SPI_nSS, bool slowSPI>
bool t_powerUpSPIIfDisabled()
    {
    ATOMIC_BLOCK (ATOMIC_RESTORESTATE)
        {
        if(!(PRR & _BV(PRSPI))) { return(false); }

        // Ensure that nSS is HIGH ASAP and thus any slave deselected when powering up SPI.
        fastDigitalWrite(SPI_nSS, HIGH);
        // Ensure that nSS is an output to avoid forcing SPI to slave mode by accident.
        pinMode(SPI_nSS, OUTPUT);

        PRR &= ~_BV(PRSPI); // Enable SPI power.

        // Configure raw SPI to match better how it was used in PICAXE V0.09 code.
        // CPOL = 0, CPHA = 0
        // Enable SPI, set master mode, set speed.
        const uint8_t ENABLE_MASTER = _BV(SPE) | _BV(MSTR);
#if F_CPU <= 2000000 // Needs minimum prescale (x2) with slow (<=2MHz) CPU clock.
        SPCR = ENABLE_MASTER; // 2x clock prescale for <=1MHz SPI clock from <=2MHz CPU clock (500kHz SPI @ 1MHz CPU).
        if(!slowSPI) { SPSR = _BV(SPI2X); } // Slow will give 4x prescale for 250kHz bus at 1MHz CPU.
#elif F_CPU <= 8000000
        SPCR = ENABLE_MASTER; // 4x clock prescale for <=2MHz SPI clock from nominal <=8MHz CPU clock.
        SPSR = 0;
#else // Needs setting for fast (~16MHz) CPU clock.
        SPCR = _BV(SPR0) | ENABLE_MASTER; // 8x clock prescale for ~2MHz SPI clock from nominal ~16MHz CPU clock.
        SPSR = _BV(SPI2X);
#endif
        }
    return(true);
    }
//
// Power down SPI.
template <uint8_t SPI_nSS, uint8_t SPI_SCK, uint8_t SPI_MOSI, uint8_t SPI_MISO, bool slowSPI>
void t_powerDownSPI()
    {
    ATOMIC_BLOCK (ATOMIC_RESTORESTATE)
        {
        // Ensure that nSS is HIGH ASAP and thus any slave deselected when powering up SPI.
        fastDigitalWrite(SPI_nSS, HIGH);

        SPCR &= ~_BV(SPE); // Disable SPI.
        PRR |= _BV(PRSPI); // Power down...

        // Ensure that nSS is an output to avoid forcing SPI to slave mode by accident.
        pinMode(SPI_nSS, OUTPUT);

        // Avoid pins from floating when SPI is disabled.
        // Try to preserve general I/O direction and restore previous output values for outputs.
        pinMode(SPI_SCK, OUTPUT);
        pinMode(SPI_MOSI, OUTPUT);
        pinMode(SPI_MISO, INPUT_PULLUP);

        // If sharing SPI SCK with LED indicator then return this pin to being an output (retaining previous value).
        //if(LED_HEATCALL == PIN_SPI_SCK) { pinMode(LED_HEATCALL, OUTPUT); }
        }
    }

// STANDARD UNTEMPLATED DEFINITIONS OF SPI power up/down if PIN_SPI_nSS is defined.
// If SPI was disabled, power it up, enable it as master and with a sensible clock speed, etc, and return true.
// If already powered up then do nothing other than return false.
// If this returns true then a matching powerDownSPI() may be advisable.
inline bool powerUpSPIIfDisabled() { return(t_powerUpSPIIfDisabled<V0p2_PIN_SPI_nSS, DEFAULT_RUN_SPI_SLOW>()); }
// Power down SPI.
inline void powerDownSPI() { t_powerDownSPI<V0p2_PIN_SPI_nSS, V0p2_PIN_SPI_SCK, V0p2_PIN_SPI_MOSI, V0p2_PIN_SPI_MISO, DEFAULT_RUN_SPI_SLOW>(); }

/************** Serial IO stuff ************************/
// Moved from Power Management.h

// Check if serial is (already) powered up.
static inline bool _serialIsPoweredUp() { return(!(PRR & _BV(PRUSART0))); }


// If serial (UART/USART0) was disabled, power it up, do Serial.begin(), and return true.
// If already powered up then do nothing other than return false.
// If this returns true then a matching powerDownSerial() may be advisable.
// Defaults to V0p2 unit baud rate
template <uint16_t baud>
bool powerUpSerialIfDisabled()
  {
  if(_serialIsPoweredUp()) { return(false); }
  PRR &= ~_BV(PRUSART0); // Enable the UART.
  Serial.begin(baud); // Set it going.
  return(true);
  }
// Flush any pending serial (UART/USART0) output and power it down.
void powerDownSerial();
#ifdef __AVR_ATmega328P__
// Returns true if hardware USART0 buffer in ATMmega328P is non-empty; may occasionally return a spurious false.
// There may still be a byte in the process of being transmitted when this is false.
// This should not interfere with HardwareSerial's handling.
#define serialTXInProgress() (!(UCSR0A & _BV(UDRE0)))
// Does a Serial.flush() attempting to do some useful work (eg I/O polling) while waiting for output to drain.
// Assumes hundreds of CPU cycles available for each character queued for TX.
// Does not change CPU clock speed or disable or mess with USART0, though may poll it.
void flushSerialProductive();
// Does a Serial.flush() idling for 30ms at a time while waiting for output to drain.
// Does not change CPU clock speed or disable or mess with USART0, though may poll it.
// Sleeps in IDLE mode for up to 15ms at a time (using watchdog) waking early on interrupt
// so the caller must be sure RX overrun (etc) will not be an issue.
// Switches to flushSerialProductive() behaviour
// if in danger of overrunning a minor cycle while idling.
void flushSerialSCTSensitive();
#else
#define flushSerialProductive() Serial.flush()
#define flushSerialSCTSensitive() Serial.flush()
#endif




} // OTV0P2BASE
#endif // OTV0P2BASE_POWERMANAGEMENT_H
