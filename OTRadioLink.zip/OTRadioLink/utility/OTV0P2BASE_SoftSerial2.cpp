/*
 * OTV0P2BASE_SoftSerial2.cpp
 *
 *  Created on: 15 Apr 2016
 *      Author: denzo
 */

#include "OTV0P2BASE_SoftSerial2.h"

namespace OTV0P2BASE
{


}
