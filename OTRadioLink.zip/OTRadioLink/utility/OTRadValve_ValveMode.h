/*
The OpenTRV project licenses this file to you
under the Apache Licence, Version 2.0 (the "Licence");
you may not use this file except in compliance
with the Licence. You may obtain a copy of the Licence at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the Licence is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied. See the Licence for the
specific language governing permissions and limitations
under the Licence.

Author(s) / Copyright (s): Damon Hart-Davis 2015--2016
*/

/*
 * Notion of basic mode of OpenTRV thermostatic radiator valve: FROST, WARM or BAKE.
 */

#ifndef ARDUINO_LIB_OTRADVALVE_VALVEMODE_H
#define ARDUINO_LIB_OTRADVALVE_VALVEMODE_H


#include <stddef.h>
#include <stdint.h>
#include <OTV0p2Base.h>
#include "OTV0P2BASE_Concurrency.h"
#include "OTV0P2BASE_Sensor.h"
#include "OTRadValve_Parameters.h"


// Use namespaces to help avoid collisions.
namespace OTRadValve
    {


// Valve device general mode, implemented as a sensor pseudo device.
// The mode can be one of:
//   * frost protection
//   * warm (normal) mode
//   * bake mode aka "make me warm now"
// The mode is accessible as either an enum value
// or via boolean tests and void setters;
// read() ensures that the two views are in sync as well as timing out a 'bake'.
//
// Indicated methods are ISR-/thread- safe.
class ValveMode final : public OTV0P2BASE::SimpleTSUint8Sensor
  {
  private:
    // If true then is in WARM (or BAKE) mode; defaults to (starts as) false/FROST.
    // Should be only be set when 'debounced'.
    // Defaults to (starts as) false/FROST.
    // Marked volatile to allow atomic access from ISR without a lock.
    volatile bool isWarmMode = false;

    // Only relevant if isWarmMode is true.
    // Marked volatile to allow atomic access from ISR without a lock;
    // decrements should lock out interrupts.
    volatile OTV0P2BASE::Atomic_UInt8T bakeCountdownM;

  public:
    // Modes.
    // Starts in VMODE_FROST.
    typedef enum mode : uint8_t { VMODE_FROST = 0, VMODE_WARM, VMODE_BAKE } mode_t;

    // Construct an instance.
    ValveMode() : bakeCountdownM(0) { }

    // Reset to default/constructed state.
    // Mainly to support unit tests.
    void reset() { bakeCountdownM.store(0); }

    // Returns true if the mode value passed is valid, ie in range [0,2].
    virtual bool isValid(const uint8_t value) const { return(value <= VMODE_BAKE); }

    // Set new mode value; if VMODE_BAKE then (re)starts the BAKE period.
    // Ignores invalid values.
    // If this returns true then the new target value was accepted.
    virtual bool set(const uint8_t newValue)
        {
        switch(newValue)
            {
            case VMODE_FROST: { setWarmModeDebounced(false); break; }
            case VMODE_WARM: { setWarmModeDebounced(true); break; }
            case VMODE_BAKE: { startBake(); break; }
            default: { return(false); } // Ignore bad values.
            }
        value = newValue;
        return(true); // Accept good value.
        }

    // Overload to allow set directly with enum value.
    bool set(const mode_t newValue) { return(set((uint8_t) newValue)); }

    // Compute state from underlying.
    uint8_t _get() const
        {
        if(!isWarmMode) { return(VMODE_FROST); }
        if(0 != bakeCountdownM.load()) { return(VMODE_BAKE); }
        return(VMODE_WARM);
        }

    // Call this nominally every minute to manage internal state (eg run down the BAKE timer).
    // Not thread-/ISR- safe.
    virtual uint8_t read()
      {
      OTV0P2BASE::safeDecIfNZWeak(bakeCountdownM);
      // Recompute value from underlying.
      value = _get();
      return(value);
      }

    // Preferred poll interval (in seconds); should be called at constant rate, usually 1/60s.
    virtual uint8_t preferredPollInterval_s() const { return(60); }

    // Original V0p09/V0p2 API.
    // If true then the unit is in 'warm' (heating) mode (or bake),
    // else 'frost' protection mode.
    // Is thread-/ISR- safe.
    bool inWarmMode() const { return(isWarmMode); }
    // Has the effect of forcing the warm mode to the specified state immediately.
    // Should be only be called once 'debounced'
    // if coming from a button press for example.
    // If forcing to FROST mode then any pending BAKE time is cancelled.
    void setWarmModeDebounced(const bool warm)
      {
      isWarmMode = warm;
      if(!warm) { cancelBakeDebounced(); }
      }
    // If true then the unit is in 'BAKE' mode, a subset of 'WARM' mode which boosts the temperature target temporarily.
    // ISR-safe (though may yield stale answer if warm is set false concurrently).
    bool inBakeMode() const { return(isWarmMode && (0 != bakeCountdownM.load())); }
    // Should be only be called once 'debounced'
    // if coming from a button press for example.
    // Cancel 'bake' mode if active; does not force to FROST mode.
    // Is thread-/ISR- safe (though may have no effect).
    void cancelBakeDebounced() { bakeCountdownM.store(0); }
    // Start/restart 'BAKE' mode and timeout.
    // Should ideally be only be called once 'debounced'
    // if coming from a button press for example.
    // Is thread-/ISR- safe (though may have no effect if warm is set false concurrently).
    void startBake() { isWarmMode = true; bakeCountdownM.store(DEFAULT_BAKE_MAX_M); }
  };


    }

#endif
